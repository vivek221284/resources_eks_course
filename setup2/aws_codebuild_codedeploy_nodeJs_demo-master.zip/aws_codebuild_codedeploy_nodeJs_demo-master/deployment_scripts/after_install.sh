#!/bin/bash
cd /home/ubuntu/app
npm install